<?php
/* Smarty version 3.1.32, created on 2018-06-11 11:20:44
  from 'C:\Users\daanh\Desktop\Bureaublad\Schoolwerk\MyBand1\private\views\notfound.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1e3eec3d8c13_48312997',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b5c094823e191dd4ada5a2c4214728ef30d4fc99' => 
    array (
      0 => 'C:\\Users\\daanh\\Desktop\\Bureaublad\\Schoolwerk\\MyBand1\\private\\views\\notfound.tpl',
      1 => 1528708707,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b1e3eec3d8c13_48312997 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>Error 404 - Page not found</h1><?php }
}
