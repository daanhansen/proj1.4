<?php
/* Smarty version 3.1.32, created on 2018-06-19 10:04:43
  from 'C:\Users\daanh\Desktop\Bureaublad\Schoolwerk\MyBand1\private\views\home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b28b91bd79496_74596878',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '13438206f986e74faebedbb7ad0d494d5535ef18' => 
    array (
      0 => 'C:\\Users\\daanh\\Desktop\\Bureaublad\\Schoolwerk\\MyBand1\\private\\views\\home.tpl',
      1 => 1529309587,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b28b91bd79496_74596878 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>Hallo!</h1> <br>
<p>De voornamen zijn:
<ul>

    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['voornamen']->value, 'voornaam');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['voornaam']->value) {
?>
        <li><?php echo $_smarty_tpl->tpl_vars['voornaam']->value;?>
</li>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

</ul>
</p><?php }
}
