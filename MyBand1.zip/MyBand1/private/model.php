<?php

function make_connection() {
    $mysqli = new mysqli('localhost', '22751', 'wljxuwjm', '22751mb_db');
    if ($mysqli->connect_errno) {
        die('Connection error: ' . $mysqli->connect_errno() . '<br>');
    }
    return $mysqli;
}


function get_voornamen() {
    $mysqli = make_connection();
    $query = "SELECT vn FROM users";
    $statement = $mysqli->prepare($query) or die("Error preparing. [1]");
    $statement->bind_result($voornaam) or die("Error binding results. [1]");
    $statement->execute() or die("Error executing. [1]");
    $results = array();
    while ($statement->fetch()) {
        $results[] = $voornaam;
    }
    return $results;
}


