<?php

function homepage_action($smarty) {
    $voornamen = get_voornamen();
    $smarty->assign('voornamen', $voornamen);
    $smarty->display('home.tpl');
}

function page_not_found_action($smarty) {
    $smarty->display('notfound.tpl');
}